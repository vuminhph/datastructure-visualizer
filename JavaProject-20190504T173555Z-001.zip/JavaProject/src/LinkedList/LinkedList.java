package LinkedList;


import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javafx.animation.AnimationTimer;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LinkedList extends Stage {
	private int y = -1;
	public LinkedList() {
		TextField id = new TextField();
		TextField searchId = new TextField();
		
		id.setLayoutX(205);
		searchId.setLayoutX(205);
		searchId.setLayoutY(60);
		Class<?> clazz = this.getClass();
		InputStream input = clazz.getResourceAsStream("/ActionPoses/chay1.png");
		Image image = new Image(input); 
		

		InputStream input1 = clazz.getResourceAsStream("/ActionPoses/chay2.png");
		Image image1 = new Image(input1); 
		
		InputStream inputH = clazz.getResourceAsStream("/ActionPoses/head.png");
		Image imageH = new Image(inputH); 
		
		InputStream inputDt = clazz.getResourceAsStream("/ActionPoses/dangtay.png");
		Image imageDt = new Image(inputDt); 
		
		InputStream inputGt = clazz.getResourceAsStream("/ActionPoses/gioTay.png");
		Image imageGt = new Image(inputGt); 
		
		InputStream inputDel = clazz.getResourceAsStream("/ActionPoses/del.png");
		Image imageDel = new Image(inputDel); 
		
		//set Null line
		Line lineNull = new Line();
		lineNull.setStartY(420);
		lineNull.setEndY(520);
		lineNull.setStartX(400);
		lineNull.setEndX(400);
		lineNull.setStrokeWidth(4);

		ArrayList<ImageView> imageViewDt = new ArrayList<ImageView>();

		ImageView imageViewGt = new ImageView(imageGt);
		ImageView imageView = new ImageView(image);
		ImageView imageView1 = new ImageView(image1);
		ImageView imageViewDel = new ImageView(imageDel);
		ImageView imageViewH = new ImageView(imageH);

		
		Pane root = new Pane();
		ArrayList<VBox> box = new ArrayList<VBox>();
		//		VBox[] box = new VBox[50];
		root.getChildren().add(lineNull);
		ArrayList<String> t = new ArrayList<String>(); 
		Button insertHead = new Button("Insert Head");
		Button insertTail = new Button("Insert Tail");
		Button insertBefore = new Button("Insert Before");
		Button insertAfter = new Button("Insert After");
		Button deleteAfter = new Button("Delete After");
		root.getChildren().addAll(insertHead,insertTail,insertBefore,id,searchId,insertAfter,deleteAfter);

		insertTail.setLayoutY(30);
		insertBefore.setLayoutY(60);
		insertAfter.setLayoutY(90);
		deleteAfter.setLayoutY(120);
		
		deleteAfter.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event){
				
				y--;
				String sId = searchId.getText();
				
				deleteAfter(box,0,image,image1,imageDel,lineNull,imageViewGt,imageViewDt,imageView, imageView1,imageViewDel,imageViewH,root,sId,t);
				
			}
		});
		insertAfter.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event){
				y++;
				TranslateTransition transNull = new TranslateTransition();
				transNull.setNode(lineNull);
				transNull.setToX((y+1)*67);
				transNull.setDuration(Duration.seconds(0.7));;
				transNull.play();
				String sId = searchId.getText();
				String txt = id.getText();

				insertAfter(box,0,imageDt,imageViewGt,imageViewDt,imageView, imageView1,imageViewH,root,sId,txt,t);
			}
		});
		
		insertTail.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event){
				y++;
				TranslateTransition transNull = new TranslateTransition();
				transNull.setNode(lineNull);
				transNull.setToX((y+1)*67);
				transNull.setDuration(Duration.seconds(0.7));;
				transNull.play();
				
				
				String txt = id.getText();

				int tmp = insertAfter(box,0,imageDt,imageViewGt,imageViewDt,imageView, imageView1,imageViewH,root,t.get(y-1),txt,t);
			}
		});
		insertHead.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event){
				y++;
				TranslateTransition transNull = new TranslateTransition();
				transNull.setNode(lineNull);
				transNull.setToX((y+1)*67);
				transNull.setDuration(Duration.seconds(1.5));;
				transNull.play();
				String txt = id.getText();
				t.add(0,txt);
				//move all the nodes to its location
				for (int i = 0; i < y; i++) {
					if (Integer.parseInt(t.get(i)) != -1) {
						TranslateTransition trans = new TranslateTransition();
						trans.setNode(box.get(i));
						trans.setDuration(Duration.seconds(1.5));
						trans.setToX(400+(i+1)*67);
						trans.play();
					}
						
				}
				imageViewDt.add(0,new ImageView(imageDt));


				insertAtPos(box,400,0,imageView,imageView1, imageViewDt,imageViewH,root,txt);
			}
		});
		
		insertBefore.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event){
				
				y++;
				TranslateTransition transNull = new TranslateTransition();
				transNull.setNode(lineNull);
				transNull.setToX((y+1)*67);
				transNull.setDuration(Duration.seconds(0.7));;
				transNull.play();
				
				String sId = searchId.getText();
				String txt = id.getText();
				
				int tmp = insertBefore(box,0,imageDt,imageViewGt,imageViewDt,imageView, imageView1,imageViewH,root,sId,txt,t);

				

			}
		});
		
		Scene scene = new Scene(root,1000,800);
		this.setScene(scene); 	
	    this.show();
	}
	public int insertAfter(ArrayList<VBox> box,int pos, Image imageDt, 
			ImageView imageViewGt,ArrayList<ImageView> imageViewDt,ImageView imageView, ImageView imageView1,ImageView imageViewH,
			Pane root, String sId, String txt, ArrayList<String> t) {
		int tmp = pos;


		//up and down animation
		TranslateTransition trans = new TranslateTransition();
		trans.setDuration(Duration.seconds(1));
		trans.setNode(box.get(tmp));
		trans.setToY(-150);
		TranslateTransition trans1 = new TranslateTransition();
		trans1.setDuration(Duration.seconds(1));
		trans1.setNode(box.get(tmp));
		trans1.setToY(-100);
		if (tmp == 0)
			box.get(tmp).getChildren().remove(imageViewH);
		else box.get(tmp).getChildren().remove(imageViewDt.get(tmp));
		box.get(tmp).getChildren().add(imageViewGt);
		trans.play();
		trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
			@Override
		    public void handle(ActionEvent event) {
				trans1.play();
				trans1.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {
						box.get(tmp).getChildren().remove(imageViewGt);
						//if tmp = 0, return head image
						if (tmp == 0)
							box.get(tmp).getChildren().add(imageViewH);
						else box.get(tmp).getChildren().add(imageViewDt.get(tmp));
						if (t.get(tmp).equals(sId)) {

							imageViewDt.add(tmp+1,new ImageView(imageDt));
							//if search = true, insert at tmp 
							insertAtPos(box,400+(tmp+1)*60,tmp+1,imageView,imageView1, imageViewDt,imageViewH,root,txt);
							t.add(tmp+1,txt);
							//move all the nodes to its location
							for (int j = tmp+2; j < y+1; j++) {
								TranslateTransition trans = new TranslateTransition();
								trans.setNode(box.get(j));
								trans.setDuration(Duration.seconds(1.5));
								trans.setToX(400+(j)*67);
								trans.play();
								
							}
							

							return;
						}
						//recursively call the method at tmp = tmp +1
						else insertAfter(box,tmp+1,imageDt,imageViewGt,imageViewDt,imageView, imageView1,imageViewH,root,sId,txt,t);
					}
				});
			}
		});
		return tmp;
	}

	public int insertBefore(ArrayList<VBox> box,int pos, Image imageDt, 
			ImageView imageViewGt,ArrayList<ImageView> imageViewDt,ImageView imageView, ImageView imageView1,ImageView imageViewH,
			Pane root, String sId, String txt, ArrayList<String> t) {
		int tmp = pos;
		
		//up and down animation
		TranslateTransition trans = new TranslateTransition();
		trans.setDuration(Duration.seconds(1));
		trans.setNode(box.get(tmp));
		trans.setToY(-150);
		TranslateTransition trans1 = new TranslateTransition();
		trans1.setDuration(Duration.seconds(1));
		trans1.setNode(box.get(tmp));
		trans1.setToY(-100);
		if (tmp == 0)
			box.get(tmp).getChildren().remove(imageViewH);
		else box.get(tmp).getChildren().remove(imageViewDt.get(tmp));
		box.get(tmp).getChildren().add(imageViewGt);
		trans.play();
		trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
			@Override
		    public void handle(ActionEvent event) {
				trans1.play();
				trans1.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {
						box.get(tmp).getChildren().remove(imageViewGt);
						//if tmp = 0, return head image
						if (tmp == 0)
							box.get(tmp).getChildren().add(imageViewH);
						else box.get(tmp).getChildren().add(imageViewDt.get(tmp));
						
						
						if (t.get(tmp).equals(sId)) {

							imageViewDt.add(tmp,new ImageView(imageDt));
							//if search = true, insert at tmp 
							insertAtPos(box,400+tmp*60,tmp,imageView,imageView1, imageViewDt,imageViewH,root,txt);
							t.add(tmp,txt);
							for (int j = tmp+1; j < y+1; j++) {
								TranslateTransition trans = new TranslateTransition();
								trans.setNode(box.get(j));
								trans.setDuration(Duration.seconds(1.5));
								trans.setToX(400+(j)*67);
								trans.play();
								
							}
							
							
							return;
						}
						//recursively call the method at tmp = tmp +1
						else insertBefore(box,tmp+1,imageDt,imageViewGt,imageViewDt,imageView, imageView1,imageViewH,root,sId,txt,t);
					}
				});
			}
		});
		


		return tmp;
	}
	
	public void insertAtPos(ArrayList<VBox> box, int max,int pos,
			ImageView imageView,ImageView imageView1, ArrayList<ImageView> imageViewDt,ImageView imageViewH,Pane root,String txt) {

		//set box object
		VBox box1 = new VBox();
		box1.setSpacing(25);
		box.add(pos,box1);
		box.get(pos).setLayoutY(500);

		Text text = new Text(txt);
		box.get(pos).getChildren().addAll(text);
		root.getChildren().add(box.get(pos));
		
		//set animation
		AnimationTimer timer = new AnimationTimer() {
			@Override
			public void handle(long l) {
				//set speed
				box.get(pos).setTranslateX(box.get(pos).getTranslateX() + 5);
				
				//run until hit max
				if (box.get(pos).getTranslateX() % 50 == 0 && box.get(pos).getTranslateX()/2 % 50 != 0) {
					box.get(pos).getChildren().remove(imageView);
					box.get(pos).getChildren().add(imageView1);
				}
				if (box.get(pos).getTranslateX() % 50 == 0 && box.get(pos).getTranslateX()/2 % 50 == 0) {
					box.get(pos).getChildren().add(imageView);
					box.get(pos).getChildren().remove(imageView1);
				}
				
				if (box.get(pos).getTranslateX() > max) {
					box.get(pos).getChildren().remove(imageView);
					box.get(pos).getChildren().remove(imageView1);
					if(pos == 0) {
						box.get(pos).getChildren().add(imageViewH);
						if (y >= 1)
							box.get(pos+1).getChildren().add(imageViewDt.get(pos+1));
					}

					
					else box.get(pos).getChildren().add(imageViewDt.get(pos));
					//go up from max position
					AnimationTimer timer1 = new AnimationTimer() {
						@Override
						public void handle(long l1) {
							box.get(pos).setTranslateY(box.get(pos).getTranslateY() - 5);
							if (box.get(pos).getTranslateY() == -100)
								this.stop();
						}
					};
					timer1.start();
					this.stop();
					
				}
				
				
				
				
			}
		};
		timer.start();
	}	
	
	public void deleteAfter(ArrayList<VBox> box,int pos,Image image, Image image1,Image imageDel,Line lineNull,
			ImageView imageViewGt,ArrayList<ImageView> imageViewDt,ImageView imageView, ImageView imageView1,
			ImageView imageViewDel,ImageView imageViewH,Pane root, String sId, ArrayList<String> t) {
		int tmp = pos;
		//up and down animation
		TranslateTransition trans = new TranslateTransition();
		trans.setDuration(Duration.seconds(1));
		trans.setNode(box.get(tmp));
		trans.setToY(-150);
		TranslateTransition trans1 = new TranslateTransition();
		trans1.setDuration(Duration.seconds(1));
		trans1.setNode(box.get(tmp));
		trans1.setToY(-100);
		if (tmp == 0)
			box.get(tmp).getChildren().remove(imageViewH);
		else box.get(tmp).getChildren().remove(imageViewDt.get(tmp));
		box.get(tmp).getChildren().add(imageViewGt);
		trans.play();
		trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
			@Override
		    public void handle(ActionEvent event) {
				trans1.play();
				trans1.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {
						box.get(tmp).getChildren().remove(imageViewGt);
						//if tmp = 0, return head image
						if (tmp == 0)
							box.get(tmp).getChildren().add(imageViewH);
						else box.get(tmp).getChildren().add(imageViewDt.get(tmp));
						if (t.get(tmp).equals(sId)) {
							//if search = true
							//remove node
							Text s = new Text(t.get(tmp+1));
							box.get(tmp+1).getChildren().remove(imageViewDt.get(tmp+1));
							box.get(tmp+1).getChildren().add(imageViewDel);
							root.getChildren().remove(box.get(tmp+1));
							box.remove(tmp+1);
							imageViewDt.remove(tmp+1);
							t.remove(tmp+1);
							//pull all the node back to its location
							for (int j = tmp+1; j < y+1; j++) {
								TranslateTransition trans = new TranslateTransition();
								trans.setNode(box.get(j));
								trans.setDuration(Duration.seconds(1.5));
								trans.setToX(400+(j)*67);
								trans.play();
								
							}
							//set run away animation
							VBox box1 = new VBox();
							ImageView i = new ImageView(image);
							ImageView i1 = new ImageView(image1);
							ImageView iDel = new ImageView(imageDel);
							box1.setSpacing(25);
							box1.getChildren().addAll(s,iDel);
							box1.setLayoutX(400+(tmp+1)*60);
							box1.setLayoutY(400);
							root.getChildren().add(box1);
							//go up
							TranslateTransition trans1 = new TranslateTransition();
							trans1.setNode(box1);
							trans1.setDuration(Duration.seconds(1));
							trans1.setToY(-150);
							trans1.play();
							trans1.onFinishedProperty().set(new EventHandler<ActionEvent>() {
								//run away
								@Override
							    public void handle(ActionEvent event) {
									box1.getChildren().remove(iDel);
									TranslateTransition transNull = new TranslateTransition();
									transNull.setNode(lineNull);
									transNull.setToX((y+1)*67);
									transNull.setDuration(Duration.seconds(0.7));;
									transNull.play();
									AnimationTimer timer = new AnimationTimer() {
										@Override
										public void handle(long l) {
											
											
											
											if (box1.getTranslateX() % 50 == 0 && box1.getTranslateX()/2 % 50 != 0) {
												box1.getChildren().remove(i);
												box1.getChildren().add(i1);
											}
											if (box1.getTranslateX() % 50 == 0 && box1.getTranslateX()/2 % 50 == 0) {
												box1.getChildren().add(i);
												box1.getChildren().remove(i1);
											}
											box1.setTranslateX(box1.getTranslateX() + 5);
										}
									};
									timer.start();
								}
							});
							return ;
						}
						//recursively call the method at tmp = tmp +1
						else deleteAfter(box,tmp+1,image,image1,imageDel,lineNull,imageViewGt,imageViewDt,imageView, imageView1,imageViewDel,imageViewH,root,sId,t);
					}
				});
				
			}
			
		});
		
	}
	

}
