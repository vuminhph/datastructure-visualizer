package LinkedList;


import java.io.InputStream;

import javafx.animation.AnimationTimer;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LinkedListAnimation extends Application {
//	public void initialize(URL location, ResourceBundle resources) {
//		 
//	       // TODO (don't really need to do anything here).
//	      
//	   }
//	public void showLinkedList(ActionEvent event) throws IOException {
//		Pane root = FXMLLoader.load(getClass().getResource("LinkedListVisual.fxml"));
//		
//	}
	@Override
	public void start(Stage stage) {
		Class<?> clazz = this.getClass();
		InputStream input = clazz.getResourceAsStream("/ActionPoses/chay1.png");
		Image image = new Image(input); 
		ImageView imageView = new ImageView(image);

		InputStream input1 = clazz.getResourceAsStream("/ActionPoses/chay2.png");
		Image image1 = new Image(input1); 
		ImageView imageView1 = new ImageView(image1);
		imageView.setScaleX(1.5);
		imageView.setScaleY(1.5);
		imageView1.setScaleX(1.5);
		imageView1.setScaleY(1.5);
		imageView.setLayoutX(10);
		imageView.setLayoutY(30);
		imageView1.setLayoutX(10);
		imageView1.setLayoutY(30);
		Pane root = new Pane();
		
		root.setPadding(new Insets(100));
		root.getChildren().add(imageView);
		AnimationTimer timer = new AnimationTimer() {
			@Override
			public void handle(long l) {
				imageView.setTranslateX(imageView.getTranslateX() + 2.5);
				imageView1.setTranslateX(imageView1.getTranslateX()+ 2.5);
				if (imageView.getTranslateX() > 300) {
					root.getChildren().remove(imageView);
					root.getChildren().remove(imageView1);
					return;
				}
				if (imageView.getTranslateX() % 20 == 0 && imageView.getTranslateX()/2 % 20 != 0) {
					root.getChildren().remove(imageView);
					root.getChildren().add(imageView1);
				}
				if (imageView.getTranslateX() % 20 == 0 && imageView.getTranslateX()/2 % 20 == 0) {
					root.getChildren().add(imageView);
					root.getChildren().remove(imageView1);
				}

			}
		};
		if (imageView.getTranslateX() == 20) 
			timer.stop();
		
		timer.start();
		Scene scene = new Scene(root, 400, 200);
		stage.setScene(scene);
	    stage.show();
	}
    
	public static void main(String[] args) {
        Application.launch(args);
    }
}
