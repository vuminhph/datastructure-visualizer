package application;

import LinkedList.LinkedList;
import Stack.Stack;
import avl.TreeShow;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
 
public class Main  extends Application {

  
    @Override
    public void start(Stage primaryStage) {
        try {

         
            Button stack = new Button("Stack");
            stack.setOnAction(new EventHandler<ActionEvent>() {
            	@Override	
    			public void handle(ActionEvent event) {
            		Stack stack = new Stack();
    				stack.show();
    			}
            });
            FlowPane root = new FlowPane();
            Button linkedList = new Button("Linked List");
            linkedList.setOnAction(new EventHandler<ActionEvent>() {
            	@Override	
    			public void handle(ActionEvent event) {
            		LinkedList ll = new LinkedList(); 
    				ll.show();
    			}
            });
           
            Scene scene = new Scene(root, 800,600);
            primaryStage.setTitle("ATN's Application");
            primaryStage.setScene(scene);
            primaryStage.show();
            Button tree = new Button("AVL Tree");
            tree.setOnAction(new EventHandler<ActionEvent>() {
            	@Override	
    			public void handle(ActionEvent event) {
            		TreeShow tree = new TreeShow();
            		tree.show();
            	}
            });
            root.getChildren().addAll(stack,linkedList,tree);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    

    
    public static void main(String[] args) {
        Application.launch(args);
    }
    
}