package avl;

import java.util.ArrayList;
import java.util.Stack;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

class AVLTree{ 
	public int dy = 50;
	public int dx = 25;
	public double speed = 0.2;
	public Node root; 
	public Stack<Node> stack = new Stack<Node>();
	public int dkey;
	// A utility function to get the height of the tree 
	int height(Node N) { 
		if (N == null) 
			return 0; 

		return N.height; 
	} 

	// A utility function to get maximum of two integers 
	int max(int a, int b) { 
		return (a > b) ? a : b; 
	} 

	// A utility function to right rotate subtree rooted with y 
	// See the diagram given above. 
	Node rightRotate(Node y) { 
		Node x = y.left; 
		Node T2 = x.right; 

		// Perform rotation 
		x.right = y; 
		y.left = T2; 

		// Update heights 
		y.height = max(height(y.left), height(y.right)) + 1; 
		x.height = max(height(x.left), height(x.right)) + 1; 

		// Return new root 
		return x; 
	} 

	// A utility function to left rotate subtree rooted with x 
	// See the diagram given above. 
	Node leftRotate(Node x) { 
		Node y = x.right; 
		Node T2 = y.left; 

		// Perform rotation 
		y.left = x; 
		x.right = T2; 

		//  Update heights 
		x.height = max(height(x.left), height(x.right)) + 1; 
		y.height = max(height(y.left), height(y.right)) + 1; 

		// Return new root 
		return y; 
	} 

	// Get Balance factor of node N 
	int getBalance(Node N) { 
		if (N == null) 
			return 0; 

		return height(N.left) - height(N.right); 
	} 


	void insertAnimation(Node node, Node ins, Circle cir) {
		if (node == null)

			return;


		TranslateTransition trans = new TranslateTransition();
		trans.setDuration(Duration.seconds(speed));
		trans.setNode(cir);
		trans.setToX(node.x-600);
		trans.setToY(node.y-100);
		trans.play();
		trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (ins.key < node.key) 
					insertAnimation(node.left, ins,cir);
				if (ins.key > node.key)
					insertAnimation(node.right,ins,cir);
				else return;
			}
		});
		return;
	}		
	
	void minValAnimation(Node node, Circle cir) {
		if (node == null)
			return;
		TranslateTransition trans = new TranslateTransition();
		trans.setDuration(Duration.seconds(speed));
		trans.setNode(cir);
		trans.setToX(node.x-600);
		trans.setToY(node.y-100);
		trans.play();
		trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				minValAnimation(node.left, cir);
			}
		});
		
		/* loop down to find the leftmost leaf */



	}

	void deleteAnimation(Node node, int key, Circle cir) {
		if (node == null)  
			return;  
	
		
		TranslateTransition trans = new TranslateTransition();
		trans.setDuration(Duration.seconds(speed));
		trans.setNode(cir);
		trans.setToX(node.x-600);
		trans.setToY(node.y-100);
		trans.play();
		trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (key < node.key)  
					deleteAnimation(node.left, key,cir);  

				else if (key > node.key)  
					deleteAnimation(node.right, key,cir);  

				else
				{  	

					// node with only one child or no child  
					if ((node.left == null) || (root.right == null))  
					{  
						if (node.left != null) {
							TranslateTransition trans = new TranslateTransition();
							trans.setDuration(Duration.seconds(speed));
							trans.setNode(cir);
							trans.setToX(node.left.x-600);
							trans.setToY(node.left.y-100);
							trans.play();
						}
						else if(node.right != null) {
							TranslateTransition trans = new TranslateTransition();
							trans.setDuration(Duration.seconds(speed));
							trans.setNode(cir);
							trans.setToX(node.right.x-600);
							trans.setToY(node.right.y-100);
							trans.play();
						}

						
					}  
					else
					{  
						minValAnimation(node.right,cir);
					}  
				}  
			}
		});
	
	}

	Node insert(Node node, Node ins, double x, double y, int dis) { 

		/* 1.  Perform the normal BST insertion */
		if (node == null) {
			ins.x = x;
			ins.y = y;

			TranslateTransition trans = new TranslateTransition();
			trans.setDuration(Duration.seconds(speed));
			trans.setNode(ins.nodeTree);
			trans.setToX(ins.x);
			trans.setToY(ins.y);
			trans.play();
			return (ins); 
		}
		stack.push(node);
		if (ins.key < node.key) 
			node.left = insert(node.left, ins, node.x-dis, y+dy,dis); 
		else if (ins.key > node.key) 
			node.right = insert(node.right, ins, node.x+dis, y+dy, dis); 
		else // Duplicate keys not allowed 
			return node;

		/* 2. Update height of this ancestor node */
		node.height = 1 + max(height(node.left), 
				height(node.right)); 

		return node;

	} 

	Node insertSelfBalancing(Node node, int key) { 

		/* 1.  Perform the normal BST insertion */
		if (node == null) 
			return (new Node(key)); 

		if (key < node.key) 
			node.left = insertSelfBalancing(node.left, key); 
		else if (key > node.key) 
			node.right = insertSelfBalancing(node.right, key); 
		else // Duplicate keys not allowed 
			return node; 

		/* 2. Update height of this ancestor node */
		node.height = 1 + max(height(node.left), 
				height(node.right)); 

		/* 3. Get the balance factor of this ancestor 
              node to check whether this node became 
              unbalanced */
		int balance = getBalance(node); 

		// If this node becomes unbalanced, then there 
		// are 4 cases Left Left Case 
		if (balance > 1 && key < node.left.key) 
			return rightRotate(node); 

		// Right Right Case 
		if (balance < -1 && key > node.right.key) 
			return leftRotate(node); 

		// Left Right Case 
		if (balance > 1 && key > node.left.key) { 
			node.left = leftRotate(node.left); 
			return rightRotate(node); 
		} 

		// Right Left Case 
		if (balance < -1 && key < node.right.key) { 
			node.right = rightRotate(node.right); 
			return leftRotate(node); 
		} 

		/* return the (unchanged) node pointer */
		return node; 
	} 





	void traverseBalance(Circle cir, Pane pane, int key) {
		if (!stack.isEmpty()) {

			Node node = stack.pop();
			TranslateTransition trans = new TranslateTransition();
			trans.setDuration(Duration.seconds(speed));
			trans.setNode(cir);
			trans.setToX(node.x-600);
			trans.setToY(node.y-100);
			trans.play();

			trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent event) {
					traverseBalance(cir,pane, key);

					if(getBalance(node) > 1 || getBalance(node) < -1) {
						root = insertSelfBalancing(root, key);
						changeCoordinate(root, 600, 100 );
						pane.getChildren().remove(cir);
					}

				}
			});

		}

	}

	Node minValueNode(Node node)  
	{  
		Node current = node;  

		/* loop down to find the leftmost leaf */
		while (current.left != null)  
			current = current.left;  

		return current;  
	}  

	void preOrder(Node node)  
	{  
		if (node != null)  
		{  
			System.out.print(node.key + " ");  
			preOrder(node.left);  
			preOrder(node.right);  
		}  
	}  
	
	boolean isDel(Node node, int key)  
	{  
		// STEP 1: PERFORM STANDARD BST DELETE  
		if (node == null)  
			return true;  
		if(node.key != key)
			stack.push(node);
		if (key < node.key)  
			return isDel(node.left, key);  

		else if (key > node.key)  
			return isDel(node.right, key);  

		else
		{  	

			// node with only one child or no child  
			if ((node.left == null) || (node.right == null))  
			{  
				return true;
			}
			else return false;
		}
	}
	
	Node deleteNode(Node node, int key, Pane pane) {
		// STEP 1: PERFORM STANDARD BST DELETE  
		if (node == null)  
			return node;  

		if (key < node.key)  
			node.left = deleteNode(node.left, key,pane);  

		else if (key > node.key)  
			node.right = deleteNode(node.right, key,pane);  

		else
		{  	

			// node with only one child or no child  
			if ((node.left == null) || (node.right == null))  
			{  

				pane.getChildren().remove(node.nodeTree);
				Node temp = null;  
				if (temp == node.left)  
					temp = node.right;  
				else
					temp = node.left;  

				// No child case  
				if (temp == null)  
				{  
					temp = node;  
					node = null;  
				}  
				else // One child case  
				node = temp; // Copy the contents of  
				// the non-empty child  
				
			}  
			else
			{  

				
				Node temp = minValueNode(node.right);  
				deleteAnimation(node, minValueNode(node.right),pane);

		

				node.right = deleteNodeSelfBalancing(node.right, temp.key,pane);  
			}  
		}  
		return node;
	}
	
	
	Node deleteNodeSelfBalancing(Node node, int key, Pane pane)  
	{  
		// STEP 1: PERFORM STANDARD BST DELETE  
		if (node == null)  
			return node;  

		if (key < node.key)  
			node.left = deleteNodeSelfBalancing(node.left, key,pane);  

		else if (key > node.key)  
			node.right = deleteNodeSelfBalancing(node.right, key,pane);  

		else
		{  	

			// node with only one child or no child  
			if ((node.left == null) || (node.right == null))  
			{  

				pane.getChildren().remove(node.nodeTree);
				Node temp = null;  
				if (temp == node.left)  
					temp = node.right;  
				else
					temp = node.left;  

				// No child case  
				if (temp == null)  
				{  
					temp = node;  
					node = null;  
				}  
				else // One child case  
				node = temp; // Copy the contents of  
				// the non-empty child  
				
			}  
			else
			{  

				
				Node temp = minValueNode(node.right);  
				deleteAnimation(node, minValueNode(node.right),pane);

		

				node.right = deleteNodeSelfBalancing(node.right, temp.key,pane);  
			}  
		}  

		// If the tree had only one node then return  
		if (node == null)  
			return node;  

		// STEP 2: UPDATE HEIGHT OF THE CURRENT NODE  
		node.height = max(height(node.left), height(node.right)) + 1;  

		// STEP 3: GET THE BALANCE FACTOR OF THIS NODE (to check whether  
		// this node became unbalanced)  
		int balance = getBalance(node);  

		// If this node becomes unbalanced, then there are 4 cases  
		// Left Left Case  
		if (balance > 1 && getBalance(node.left) >= 0)  
			return rightRotate(node);  

		// Left Right Case  
		if (balance > 1 && getBalance(node.left) < 0)  
		{  
			node.left = leftRotate(node.left);  
			return rightRotate(node);  
		}  

		// Right Right Case  
		if (balance < -1 && getBalance(node.right) <= 0)  
			return leftRotate(node);  

		// Right Left Case  
		if (balance < -1 && getBalance(node.right) > 0)  
		{  
			node.right = rightRotate(node.right);  
			return leftRotate(node);  
		}  

		return node;  
	}  

	Node deleteAnimation(Node node, Node temp,Pane pane) {
		StackPane c = new StackPane(new Circle(20,Color.GREENYELLOW),new Text(Integer.toString(temp.key)));
		TranslateTransition trans = new TranslateTransition();
		c.setLayoutX(temp.x);
		c.setLayoutY(temp.y);
		trans.setDuration(Duration.seconds(speed));
		trans.setNode(c);
		trans.setToX(node.x-temp.x);
		trans.setToY(node.y-temp.y);
		pane.getChildren().add(c);
		trans.play();
		
		pane.getChildren().remove(node.nodeTree);
		trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				changeCoordinate(root,600,100);
				node.key = temp.key; 
				node.nodeTree.getChildren().remove(1);
				node.nodeTree.getChildren().add(new Text(Integer.toString(temp.key)));
				pane.getChildren().add(node.nodeTree);
				pane.getChildren().remove(c);
				
			}
		});
		
		return node;
	}

	void changeCoordinate(Node node, double x, double y) {
		if (node != null) {
			node.x = x;
			node.y= y;
			
			TranslateTransition trans = new TranslateTransition();
			trans.setDuration(Duration.seconds(speed*2));
			trans.setNode(node.nodeTree);
			trans.setToX(node.x);
			trans.setToY(node.y);
			trans.play();
			
			if (node.left != null)
				changeCoordinate(node.left, x-dx*Math.pow(2, node.left.height-1),y+dy);
			if(node.right !=null)
				changeCoordinate(node.right, x+dx*Math.pow(2, node.right.height-1),y+dy);


		}	
	}
	
	
	
	public ArrayList<Line> line = new ArrayList<Line>();
	void addLines(Node node, Pane pane ) {
		if(node == null) return;
		if (node.left != null) {
			Line l = new Line(node.x+20,node.y+28,node.left.x+20,node.left.y+14);
			l.setStroke(Color.GREENYELLOW);
			l.setStrokeWidth(3);
			line.add(0,l);
			pane.getChildren().add(line.get(0));
		}
		if (node.right != null) {
			Line l = new Line(node.x+20,node.y+28,node.right.x+20,node.right.y+14);
			l.setStroke(Color.GREENYELLOW);
			l.setStrokeWidth(3);
			line.add(0,l);
			pane.getChildren().add(line.get(0));
		}
		addLines(node.left, pane);
		addLines(node.right,pane);
		
		
	}

} 