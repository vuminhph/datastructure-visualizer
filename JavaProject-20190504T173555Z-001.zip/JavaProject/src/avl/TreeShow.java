package avl;

import java.util.concurrent.TimeUnit;

import javafx.animation.PauseTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;

public class TreeShow extends Stage{
	public int count = 0;
	public TreeShow() {
		Pane pane = new Pane();
		Scene scene = new Scene(pane, 1000, 800);
		AVLTree tree = new AVLTree();
		TextField id = new TextField();
		
		id.setLayoutY(50);
		
		
		Button insert = new Button("Insert");
		Button delete = new Button("Delete");
		delete.setLayoutY(150);
		insert.setLayoutY(100);

		insert.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				tree.stack.clear();
				insert.setDisable(true);
				delete.setDisable(true);
				Circle cir = new Circle(620,120,20,Color.TRANSPARENT);
				cir.setStrokeWidth(3);
				cir.setStroke(Color.BLUE);
				if(tree.root != null) {
					pane.getChildren().add(cir);
					count = tree.root.height + 1;
				}
				String insertId = id.getText();
				Node node = new Node(Integer.parseInt(insertId));
				pane.getChildren().add(node.nodeTree);
				tree.insertAnimation(tree.root, node, cir);
				
				TranslateTransition trans1 = new TranslateTransition();
				trans1.setDuration(Duration.seconds(count*tree.speed));
				trans1.setNode(new Circle(1));
				trans1.setToY(1000);
				trans1.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {

						tree.root = tree.insert(tree.root, node,600, 100, 25);
						
					}
				});
				trans1.play();

				TranslateTransition trans = new TranslateTransition();
				trans.setDuration(Duration.seconds((count*2)*tree.speed));
				trans.setNode(new Circle(1));
				trans.setToY(1000);
				trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {

						tree.traverseBalance(cir,pane,Integer.parseInt(insertId));
						for (int i = 0; i < tree.line.size();i++)
							pane.getChildren().remove(tree.line.get(i));
						tree.line.clear();
						insert.setDisable(false);
						delete.setDisable(false);
					}
				});
				trans.play();
				
				TranslateTransition trans2 = new TranslateTransition();
				trans2.setDuration(Duration.seconds((count*3+1)*tree.speed));
				trans2.setNode(new Circle(1));
				trans2.setToY(1000);
				trans2.play();
				trans2.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {
						pane.getChildren().remove(cir);
						tree.addLines(tree.root, pane);
					}
				});
			}
		});
		
		delete.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				insert.setDisable(true);
				delete.setDisable(true);
				String insertId = id.getText();
				tree.stack.clear();
				tree.dkey = Integer.parseInt(insertId);
				Circle cir = new Circle(620,120,20,Color.TRANSPARENT);
				cir.setStrokeWidth(3);
				cir.setStroke(Color.BLUE);
				if(tree.root != null) {
					pane.getChildren().add(cir);
					count = tree.root.height + 1;
				}
				tree.deleteAnimation(tree.root, tree.dkey, cir);
				TranslateTransition trans1 = new TranslateTransition();
				trans1.setDuration(Duration.seconds(count*tree.speed));
				trans1.setNode(new Circle(1));
				trans1.setToY(1000);
				trans1.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {
						pane.getChildren().remove(cir);
						for (int i = 0; i < tree.line.size();i++)
							pane.getChildren().remove(tree.line.get(i));
						tree.line.clear();
						tree.root = tree.deleteNode(tree.root,Integer.parseInt(insertId),pane);
						if (tree.isDel(tree.root, Integer.parseInt(insertId)) == true)
							tree.changeCoordinate(tree.root, 600, 100);
					}
				});
				trans1.play();
				
				TranslateTransition trans = new TranslateTransition();
				trans.setDuration(Duration.seconds(count*2*tree.speed));
				trans.setNode(new Circle(1));
				trans.setToY(1000);
				trans.play();
				trans.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {
						
						tree.root = tree.deleteNodeSelfBalancing(tree.root,Integer.parseInt(insertId),pane);
						tree.changeCoordinate(tree.root, 600, 100);
						
						insert.setDisable(false);
						delete.setDisable(false);
					}
				});
				TranslateTransition trans2 = new TranslateTransition();
				trans2.setDuration(Duration.seconds((count*2+1)*tree.speed));
				trans2.setNode(new Circle(1));
				trans2.setToY(1000);
				trans2.play();
				trans2.onFinishedProperty().set(new EventHandler<ActionEvent>() {
					@Override
				    public void handle(ActionEvent event) {
						tree.addLines(tree.root, pane);
					}
				});
				
				
			}
		});		
		pane.getChildren().addAll(id,insert,delete);
		

		System.out.println("Preorder traversal" + 
				" of constructed tree is : "); 


		this.setScene(scene);
		this.show();
		
	}
}
