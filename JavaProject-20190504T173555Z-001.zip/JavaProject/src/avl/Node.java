package avl;

import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;

class Node { 
	
	

	int key = 1, height;
	double x,y;
	Node(int d) { 
		key = d; 
		height = 1; 

		Text val = new Text(new String(Integer.toString(d)));
		nodeTree.getChildren().add(val);
		
	}
	
	StackPane nodeTree = new StackPane(new Circle(20,Color.GREENYELLOW));
	Node left, right; 
	
	
	
	
} 