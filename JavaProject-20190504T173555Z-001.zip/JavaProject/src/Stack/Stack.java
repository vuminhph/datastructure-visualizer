package Stack;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;

import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.animation.AnimationTimer;
import javafx.animation.PathTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;



public class Stack extends Stage implements Initializable  {

	private final double radius = 25;
//	private Stage stage = new Stage();
	private int x = 0;


	int[] startEven = new int[50];
	int[] startOdd = new int[50];
	
	public Stack(){
		Line lineLeft =new Line();
		lineLeft.setStartX(700-radius);
		lineLeft.setStartY(250);
		lineLeft.setEndX(700-radius);
		lineLeft.setEndY(700);
		lineLeft.setStroke(Color.DARKRED);
		lineLeft.setStrokeWidth(4);
		Line lineRight =new Line();
		lineRight.setStartX(700+radius);
		lineRight.setStartY(250);
		lineRight.setEndX(700+radius);
		lineRight.setEndY(700);
		lineRight.setStroke(Color.DARKRED);
		lineRight.setStrokeWidth(4);
		Line lineBot =new Line();
		lineBot.setStartX(700-radius);
		lineBot.setStartY(700);
		lineBot.setEndX(700+radius);
		lineBot.setEndY(700);
		lineBot.setStroke(Color.DARKRED);
		lineBot.setStrokeWidth(4);
		Label label = new Label("");
		label.setLayoutX(349.0);
		label.setLayoutY(243.0);

		Pane root = new Pane();

		root.getChildren().addAll(lineLeft, lineRight, lineBot);
		Button push = new Button("Push");
		push.setLayoutX(150);
		push.setLayoutY(700);
		root.getChildren().add(push);

		Circle[] cir = new Circle[50];
		Random r = new Random();

		push.setOnAction(new EventHandler<ActionEvent>() {

			@Override	
			
			public void handle(ActionEvent event) {

				int ranEven = 150 + r.nextInt(350);
				int ranOdd = r.nextInt(550);
				startEven[x] = ranEven;
				startOdd[x] = ranOdd;
				if (x == 450/radius/2) {
					label.setText("Stack is full!!");
				}
				else {
					PathTransition transition = new PathTransition();
					transition.setDuration(Duration.seconds(1));

					cir[x] = new Circle(radius);
					
					root.getChildren().add(cir[x]);
					Path path = new Path();
					if (x%2 == 0) {
						
						cir[x].setLayoutX(-50);
						
						cir[x].setLayoutY(startEven[x]);
						cir[x].setFill(Color.BLUEVIOLET);
//						Text text = new Text("1");
//						layout.getChildren().addAll(cir[x], text);
						ArcTo arc = new ArcTo();
						arc.setX(750);
						arc.setY(-250);
						arc.setRadiusX(100);
						arc.setRadiusY(50);
						arc.setSweepFlag(true);
						path.getElements().add(new MoveTo(0,0));
						
						path.getElements().add(arc);
						path.getElements().add(new LineTo(750,700-radius-startEven[x]-radius*2*x));
					}
					else {
						
						cir[x].setLayoutX(startOdd[x]);
						cir[x].setLayoutY(1050);
						cir[x].setFill(Color.ORANGERED);
						ArcTo arc = new ArcTo();
						arc.setX(700-startOdd[x]);
						arc.setY(-800);
						arc.setRadiusX(100);
						arc.setRadiusY(150);
						arc.setSweepFlag(true);
						path.getElements().add(new MoveTo(0,0));
						path.getElements().add(arc);
						path.getElements().add(new LineTo(700-startOdd[x],-350-radius-radius*2*x));
						
					}
					

					transition.setNode(cir[x]);
					transition.setPath(path);
					transition.play();
					x++;
					label.setText("");
				}

            }
		});
		Button pop = new Button("Pop");
		pop.setLayoutX(150);
		pop.setLayoutY(600);
		root.getChildren().add(pop);
		pop.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (x == 0) {
					label.setText("Stack is empty!!");
				}
				else {
					x--;
					PathTransition transition = new PathTransition();
					transition.setDuration(Duration.seconds(1));
					Path path = new Path();
					ArcTo arc = new ArcTo();
					int ran = -200 + r.nextInt(1000);
					if (x%2 == 0) {	
						path.getElements().add(new MoveTo(750,700-radius-startEven[x]-radius*2*x));
						path.getElements().add(new LineTo(750,250+radius-startEven[x]));
					}
					else {
						path.getElements().add(new MoveTo(700-startOdd[x],-350-radius-75*x));
						path.getElements().add(new LineTo(700-startOdd[x],-800-radius));
					}
					arc.setX(1200);
					arc.setY(ran);
					arc.setRadiusX(100);
					arc.setRadiusY(150);
					arc.setSweepFlag(true);
					
					path.getElements().add(arc);
					transition.setNode(cir[x]);
					transition.setPath(path);
					transition.play();
					
				}
			}
		});
		root.getChildren().add(label);
		
		this.setScene(new Scene(root,1000,800));
		this.setTitle("Stack");
		this.show();
	}

	



	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}



